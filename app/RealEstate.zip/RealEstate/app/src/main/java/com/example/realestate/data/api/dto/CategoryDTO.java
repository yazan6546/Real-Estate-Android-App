package com.example.realestate.data.api.dto;

import com.google.gson.annotations.SerializedName;

public class CategoryDTO {

    @SerializedName("id")
    public int id;

    @SerializedName("name")
    public String name;
}
